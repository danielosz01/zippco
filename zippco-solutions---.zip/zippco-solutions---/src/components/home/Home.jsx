import React from "react";
import { Header } from "../ui/Header";
import { Navbar } from "../ui/Navbar";

export const Home = () => {
  return (
    <>
      <Navbar />
      <Header />
    </>
  );
};
